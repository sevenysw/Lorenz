# Data-driven-super-parametrization-with-deep-learning
All codes related to the paper "Data-driven super-parameterization with deep learning: Experimentation with a Lorenz 96 system and transfer-learning". Most of these codes are written and maintained by my friend, Adam Subel (as170@rice.edu). 
